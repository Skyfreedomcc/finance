package com.finance.financesystem.service;

import com.finance.financesystem.entity.Employee;
import com.baomidou.mybatisplus.extension.service.IService;

public interface IEmployeeService extends IService<Employee> {}